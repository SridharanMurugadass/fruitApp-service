﻿using com.anz.producer.ANZ.api.messaging;
using com.anz.producer.ANZ.api.scripts;
using com.anz.producer.Interface;
using System.Net.Security;
using ChoETL;

namespace com.anz.ConvertFileToJson
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Processing CSV file....");

            IConvertToJson csvToJson = new Converter();

            string filePath = AppDomain.CurrentDomain.BaseDirectory + "//TestData//TestAnzFile.csv";

            string data = csvToJson.ConvertToJson(filePath);

            StringBuilder sb = new StringBuilder();

            using (var p = ChoCSVReader.LoadText(data)
                .WithFirstLineHeader()
                )
            {
                using (var w = new ChoJSONWriter(sb))
                    w.Write(p);
            }

            Console.WriteLine(sb.ToString());

            Console.WriteLine("Sending Data to Kafka");


            Kafka.SendData(data).Wait();
        }
    }
}   