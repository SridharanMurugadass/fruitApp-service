﻿using com.anz.producer.Interface;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Threading.Tasks;

namespace com.anz.producer.ANZ.api.scripts
{
    internal class Converter : IConvertToJson
    {
        private static string Serialize<T>(T item) => JsonSerializer.Serialize(item, new JsonSerializerOptions
        {
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
        });

        public string ConvertToJson(string sourceFilePath)
        {
            return GetJsonString(sourceFilePath);
        }

        public void ConvertToJson(string sourceFilePath, string destinationJsonFilePath)
        {
            string data = GetJsonString(sourceFilePath);

            File.WriteAllText(destinationJsonFilePath, data);

        }

        private string GetJsonString(string filePath)
        {
            var csv = new List<string[]>();
            var lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
                csv.Add(line.Split(','));

            var properties = lines[0].Replace("\"", "").Split(',');

            var listObjResult = new List<Dictionary<string, string>>();

            for (int i = 1; i < lines.Length; i++)
            {
                var objResult = new Dictionary<string, string>();
                for (int j = 0; j < properties.Length; j++)
                    objResult.Add(properties[j], csv[i][j].Replace("\"", ""));

                listObjResult.Add(objResult);
            }

            return Serialize(listObjResult);
        }
    }
}
